# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/sec:clamconf/;
$ref_files{$key} = "$dir".q|node36.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:components/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:clamavmilter/;
$ref_files{$key} = "$dir".q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/On-access/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/clamd/;
$ref_files{$key} = "$dir".q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/conf:freshclam/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/unit-testing/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:freshclam/;
$ref_files{$key} = "$dir".q|node35.html|; 
$noresave{$key} = "$nosave";

1;

