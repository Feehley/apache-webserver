#!/bin/sh
. $abs_srcdir/check_common.sh
test_clamscan 1
